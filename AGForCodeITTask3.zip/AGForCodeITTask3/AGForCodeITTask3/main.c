//
//  main.c
//  AGForCodeITTask3
//
//  Created by Anton Gorlov on 21.05.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

/*
 3) Write function which checks if parameter (number) is a power of three. Do it without usage of a loop or recursion.
 */
#include <stdio.h>
#include <stdbool.h>
#include <math.h>

bool isPowerOf(int power, int number)
{
    double p = (log (number)/log (power));
    
    int intA = (int)p;
    return (p - intA) == 0;
}

int main(int argc, const char * argv[]) {
    
    int power  = 3;
    int number = 4782969;
    
    bool isPower = isPowerOf(power,number );
    
    if (isPower) {
        
        printf("%d is power of %d",power,number);
        
    } else {
        
        printf("%d is not power of %d",power,number);
    }
    
    printf("\n");
    return 0;

}
