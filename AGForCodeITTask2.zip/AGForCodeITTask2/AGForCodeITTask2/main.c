//
//  main.c
//  AGForCodeITTask2
//
//  Created by Anton Gorlov on 21.05.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#include <stdio.h>


/*
 2) Write function which take an input parameter array of integers. Remove duplicates in the most efficient way.
 */


int main(int argc, const char * argv[]) {
    
    int j, i, n, k, f;
    int num[245];
    
    do {
        printf("Enter the number of elements in the array (>1)\n");
        scanf("%d", &n);
        
        if (n < 2)  printf("Wrong! Try again \n");
        
    } while (n < 2);
    
    printf("Enter the value of the elements through the gap:\n");
    
    for(i = 0; i < n; i++) {
        
        scanf("%d", &num[i]);
    }
    
    printf("Your array:\n");
    
    for(i = 0; i < n; i++)
        
        printf("%d ", num[i]);
    
    f = 0;
    
    for(i = 0; i < n; i++) {
        
        for(j = i + 1; j < n; j++) {
            
            if(num[i] == num [j]) {
                
                for(k = j; k < n-1; k++)
                    
                    num[k] = num[k+1];
                
                n--;
                
                j = j-1;
                
                f = 1;
            }
        }
    }
    
    if(f == 1) {
        
        printf("\nFinal array:\n");
        
        for(i = 0; i < n; i++)
            printf("%d ", num[i]);
    }
    else {
        
        printf("\n No reps in the array \n");
    }
    
    getchar();
    getchar();
    return 0;
}




