//
//  main.c
//  AGForCodeITTask1
//
//  Created by Anton Gorlov on 21.05.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#include <stdio.h>

/*
 
 Use pure C language to solve the tasks:
 
 1) Write a function which takes an input parameter number, and returns the sum of it's digits until the result has only one digit. E.g: 128 is like 1 + 2 + 8 = 11, 11 is like = 1 + 1 = 2. 2 Is one digit so it is correct.
 */

int function(int a) //function for the sum

{
    int sum = 0;
    while (a != 0)
        
    {
        sum = sum + (a % 10);
        a = a/10;
    }
    return sum;
}

int main(int argc, const char * argv[])
{
    int a;
    printf("Input Number:");
    scanf("%d",&a);
    
    while(( a/10 ) > 0)
    {
        a = function(a);
    }
    printf("Your sum = %d\n\n",a);
    
    return 0;
}
